<!DOCTYPE html>
<html>
<head>
	<title>Local de Nascimento</title>
</head>

<body>

	<?php
	$nome = $_POST['nome'];
	$cidade = $_POST['cidade'];

	setcookie('nome',$nome,time()+60*10);	
	setcookie('cidade',$cidade,time()+60*10);
	
	header('Location: mensagem.php')

	?>

</body>
</html>