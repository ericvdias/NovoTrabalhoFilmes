<!DOCTYPE html>
<html>
<head>
	<title>Seu salario é!</title>
</head>
<body>

	<?php

	$nome = $_COOKIE['nome'];
	$cidade = 	$_COOKIE['cidade'];

	echo "$nome nasceu em $cidade" ;

	?>

</body>
</html>