<!DOCTYPE html>
<html>
<head>
	<title>Exercicio 1</title>
</head>
<body>
	<?php
	$valorHora = 15;
	$horaMes = 172;

	$valorGanho = $valorHora*$horaMes;

	echo "Valor ganho no mês é $valorGanho";

	?>

	<?php
	$tamanhoMB = 600;
	$velocidadeMS = 1.5;

	$tempo = ($tamanhoMB/$velocidadeMS)/60;

	echo "O tempo de download é de $tempo";

	?>

	<?php
		$areaM2 = 100;

		$litrosTinta = $areaM2/3;

		$valor = ($litrosTinta/18)*80;

	?>


</body>
</body>
</html>