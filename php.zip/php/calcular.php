<!DOCTYPE html>
<html>
<head>
	<title>Seu salario é!</title>
</head>
<body>

	<?php
	$salario =$_POST['salario']
	$venda = $_POST['venda']

	$comissao = ($venda* 4)/100;
	$salarioCalculado = $salario+$comissao;

	echo "Seu salario final vai ser $salarioCalculado" ;

	?>

</body>
</html>